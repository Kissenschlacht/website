export const CONFIG = {
    CONTRACT_ADDRESS: "0x39Cb750025b546676D47E6B003F3521e1F4e01d8",
    SCAN_LINK: "https://rinkeby.etherscan.io/address/0x39Cb750025b546676D47E6B003F3521e1F4e01d8",
    NETWORK: {
        NAME: "Rinkeby Testnet",
        SYMBOL: "ETH",
        ID: 0,
    },
};