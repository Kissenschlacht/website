let title;
let compounder;
let selectNetwork;
let selectSwap;
let ButtonsearchComp;
let compounders;
let btnDep;
let btnWith;
let submit;
let navLinks;
let alreadySelected = false;
let networks;
let listCompounders;
let searchBox;
document.addEventListener("DOMContentLoaded", () => {
  title = document.querySelector(".text-box");
  compounder = document.querySelector(".select");
  selectNetwork = document.querySelector(".selectNetwork");
  selectSwap = document.querySelector(".selectSwap");
  ButtonsearchComp = document.querySelector(".searchComp");
  compounders = document.querySelector(".compounders");
  btnDep = document.querySelectorAll(".deposit");
  btnWith = document.querySelectorAll(".withdraw");
  submit = document.querySelectorAll(".submitMoney");
  searchBox = document.querySelector(".searchBox")
    navLinks = document.getElementById("navLinks");
    networks = document.querySelector(".networks")
    listCompounders = document.querySelector(".listCompounders")
    if(window.innerWidth < 900){
        console.log(window.innerWidth)
        hideMenu();
      } 
});
const launchApp = () => {
  listCompounders.style.display = "none";
  networks.style.display = "none"
  title.style.display = "none";
  compounders.style.display = "none";
  if(window.innerWidth < 900){
    compounder.style.display = "block";
  }else{
  compounder.style.display = "flex";
  }
};
const selectNetSwap = () => {
  searchBox.style.display = "none"
  listCompounders.style.display = "none";
  networks.style.display = "none"
  title.style.display = "none";
  compounders.style.display = "none";
  compounder.style.display = "flex";
  if (alreadySelected === false) {
    launchApp();
  } else {
    if(window.innerWidth < 900){
    compounder.style.display = "block";
    selectNetwork.style.display = "block";
    selectSwap.style.display = "block";
    }else{
        selectNetwork.style.display = "inline-block";
    selectSwap.style.display = "inline-block";
    }
    let message = document.querySelector(".message");
    message.innerHTML = `<br><h1>For changing the Network and Swap please relaunch the App (Go to Home)</h1>`;
    message.style.display = "block";
    message.style.textAlign = "center";
    message.style.color = "white";
    message.style.fontSize = "15px";
  }
};
const confirmNetwork = () => {
  searchBox.style.display = "none"
  networks.style.display = "none"
  let e = document.querySelector("#Network");
  let Network = e.options[e.selectedIndex].text;
  selectNetwork.innerHTML = `<h1>Network: ${Network}</h1>`;
  if(window.innerWidth < 900){
    selectNetwork.style.textAlign = "center"
    selectNetwork.querySelector("h1").style.margin = "35px"
    selectSwap.style.display = "block";
    console.log("hi")
  }else{
    selectSwap.style.display = "inline-block";
  }
};
const confirmSwap = () => {
  searchBox.style.display = "none"
  networks.style.display = "none"
  let e = document.querySelector("#Swap");
  let Swap = e.options[e.selectedIndex].text;
  selectSwap.innerHTML = `<h1>Swap: ${Swap}</h1>`;
  ButtonsearchComp.style.display = "flex";
  if(window.innerWidth < 900){
    selectSwap.style.textAlign = "center"
    selectSwap.querySelector("h1").style.margin = "35px"
  }
};
const viewCompounders = () => {
  searchBox.style.display = "flex"
  listCompounders.style.display = "none";
  networks.style.display = "none"
  alreadySelected = true;
  selectNetwork.style.display = "none";
  selectSwap.style.display = "none";
  ButtonsearchComp.style.display = "none";
  compounders.style.display = "block";
  btnDep.forEach(function (currentBtn) {
    currentBtn.addEventListener("click", () => {
      submit.forEach(function (button) {
        button.textContent = `${currentBtn.value.toUpperCase()}`;
        button.style.backgroundColor = "aquamarine";
      });
    });
  });
  btnWith.forEach(function (currentBtn) {
    currentBtn.addEventListener("click", () => {
      submit.forEach(function (button) {
        button.textContent = `${currentBtn.value.toUpperCase()}`;
        button.style.backgroundColor = "#f44336";
      });
    });
  });
};
const showMenu = () => {
    navLinks.style.right = "-200px";
    navLinks.style.display ="block";
    let show = setInterval (() => {
        navLinks.style.right = "0";
        clearInterval(show)
    }, 1)

}

const hideMenu = () => {
    navLinks.style.right = "-200px";
    let hide = setInterval (() => {
        navLinks.style.display = "none";
        clearInterval(hide)
    }, 1000)
}


