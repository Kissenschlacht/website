let navLinks;
let compounders;
let btnDep;
let btnWith;
let submit;
let searchBox;
document.addEventListener("DOMContentLoaded", () => {
    compounders = document.querySelector(".compounders");
    btnDep = document.querySelectorAll(".deposit");
    btnWith = document.querySelectorAll(".withdraw");
    submit = document.querySelectorAll(".submitMoney");
    searchBox = document.querySelector(".searchBox")
      navLinks = document.getElementById("navLinks");
      viewCompounders();
      if(window.innerWidth < 900){
          hideMenu();
        } 
  });

const viewCompounders = () => {
  searchBox.style.marginBottom = "2%";
    searchBox.style.display = "flex"
    compounders.style.display = "block";
    btnDep.forEach(function (currentBtn) {
      currentBtn.addEventListener("click", () => {
        submit.forEach(function (button) {
          button.textContent = `${currentBtn.value.toUpperCase()}`;
          button.style.backgroundColor = "aquamarine";
        });
      });
    });
    btnWith.forEach(function (currentBtn) {
      currentBtn.addEventListener("click", () => {
        submit.forEach(function (button) {
          button.textContent = `${currentBtn.value.toUpperCase()}`;
          button.style.backgroundColor = "#f44336";
        });
      });
    });
  };
  const showMenu = () => {
    navLinks.style.right = "-200px";
    navLinks.style.display ="block";
    let show = setInterval (() => {
        navLinks.style.right = "0";
        clearInterval(show)
    }, 1)

}

const hideMenu = () => {
    navLinks.style.right = "-200px";
    let hide = setInterval (() => {
        navLinks.style.display = "none";
        clearInterval(hide)
    }, 1000)
}