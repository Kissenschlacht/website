# MultiSig Wallet Dapp

This project was bootstrapped with [Create React App](https://github.com/facebook/create-react-app).

A simple example of FrontEnd Dapp connected to a MultiSigWallet Smart-Contract

## Available Scripts

In the project directory, you can run:

### `npm start`


